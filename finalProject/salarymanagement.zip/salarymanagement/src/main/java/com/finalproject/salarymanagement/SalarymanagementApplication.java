package com.finalproject.salarymanagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SalarymanagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(SalarymanagementApplication.class, args);
	}

}
