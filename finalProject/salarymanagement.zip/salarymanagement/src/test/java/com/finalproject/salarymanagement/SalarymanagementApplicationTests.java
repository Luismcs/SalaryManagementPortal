package com.finalproject.salarymanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SalarymanagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
