package com.finalproject.collaborator;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CollaboratorApplicationTests {

	@Test
	void contextLoads() {
	}

}
